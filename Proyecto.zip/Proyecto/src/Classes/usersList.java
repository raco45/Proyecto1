/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import javax.swing.JOptionPane;

/**
 *
 * @author AROMERO
 */
public class usersList {
    private userNode first;
    private userNode last;
    private int size;
    
    //Constructor de la lista

    public usersList() {
        first = null;
        size = 0;
    }

    //Funcion para chequear si la lista esta vacia
    public boolean isEmpty() {
        return first == null;
    }

    //Funcion para obtener tama;o de la lista
    public int getSize() {
        return size;
    }

    //Funcion para insertar elemento al inicio
    public void insertAtStart(int id, String user) {
        userNode newUser = new userNode(null);
        newUser.setUser(user);
        newUser.setId(id);
        size++;
        if (first == null) {
            first = newUser;
            last = first;
        } else {
            newUser.setNext(first);
            first = newUser;
        }

    }

    //Funcion para insertar elemento al final
    
    public void insertAtEnd(int id, String user) {
        userNode newUser = new userNode(null);
        newUser.setUser(user);
        newUser.setId(id);
        size++;
        if (first == null) {
            first = newUser;
            last = first;
        } else {
            last.setNext(newUser);
            last = newUser;
        }

    }
    
    //Funcion para insertar en una posicion dada
    
    public void insertAtPos(int id, String user, int pos){
        userNode newUser = new userNode( null);
        newUser.setUser(user);
        newUser.setId(id);
        userNode aux = first;
        pos = pos -1;
        for (int i = 1; i < size; i++) {
            if (i == pos) {
                userNode temp = aux.getNext();
                aux.setNext(newUser);
                newUser.setNext(temp);
                break;
            }
            aux = aux.getNext();
        }
        size ++;
    }
    
    //Funcion insertar en posicion dada sin parametros
    
        public void insert(int pos){
        userNode newUser = new userNode( null);
        userNode aux = first;
        pos = pos -1;
        for (int i = 1; i < size; i++) {
            if (i == pos) {
                userNode temp = aux.getNext();
                aux.setNext(newUser);
                newUser.setNext(temp);
                break;
            }
            aux = aux.getNext();
        }
        size ++;
    }
    
    //Funcion para eliminar en determinada posicion
    
    public void deleteAtPos(int pos){
        if (pos == 1) {
            first = first.getNext();
            size --;
            return;
        }
        if (pos == size) {
            userNode a = first;
            userNode b = first;
            while(a != last){
                b = a;
                a = a.getNext();
            }
            
            last = b;
            last.setNext(null);
            size --;
            return;
        }
        
        userNode aux = first;
        pos = pos -1;
        for (int i = 1; i < size; i++) {
            if (i == pos) {
                userNode temp = aux.getNext();
                temp = temp.getNext();
                aux.setNext(temp);
                break;
            }
            aux = aux.getNext();
        }
        size --;
    }
    
    //Funcion para mostrar elementos
    
    public void display(){
        if (size == 0) {
            JOptionPane.showMessageDialog(null, "La lista está vacía.");
            return;            
        }
        if (first.getNext() == null) {
            JOptionPane.showMessageDialog(null, "Id " + first.getId() + " / " + "Usuario " + first.getUser());
        }
        userNode aux = first;
        JOptionPane.showMessageDialog(null, "Id " + first.getId() + " / " + "Usuario " + first.getUser());
        aux = first.getNext();
        while(aux.getNext() != null){
            JOptionPane.showMessageDialog(null, "Id " + aux.getId() + " / " + "Usuario " + aux.getUser());  
            aux = aux.getNext();
        }
        JOptionPane.showMessageDialog(null, "Id " + aux.getId() + " / " + "Usuario " + aux.getUser());       
    }
}
