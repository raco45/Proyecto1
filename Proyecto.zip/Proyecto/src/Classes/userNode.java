/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

/**
 *
 * @author AROMERO
 */
public class userNode {
    private String user;
    private int id;
    private userNode next;
    
    public userNode(userNode next){
        this.id = id;
        this.user = user;
        this.next = null;
        
    }

    /**
     * @return the user
     */
    public String getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(String user) {
        this.user = user;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the next
     */
    public userNode getNext() {
        return next;
    }

    /**
     * @param next the next to set
     */
    public void setNext(userNode next) {
        this.next = next;
    }
}
