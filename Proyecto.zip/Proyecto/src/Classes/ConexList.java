/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import javax.swing.JOptionPane;

/**
 *
 * @author AROMERO
 */

//Lista de conexiones entre los usuarios
public class ConexList {
    private int user1;
    private int user2;
    private int time;
    private ConexNode first;
    private ConexNode last;
    private int size;
    
    //Constructor de la lista

    public ConexList() {
        this.first = null;
        this.last = null;
        this.size = 0;
    }

    //Funcion para chequear si la lista esta vacia
    
    public boolean isEmpty() {
        return getFirst() == null;
    }

    //Funcion para obtener tama;o de la lista
    
    public int getSize() {
        return size;
    }

    //Funcion para insertar elemento al inicio
    
    public void insertAtStart(int user1, int user2, int time) {
        ConexNode newNode = new ConexNode(user1, user2, time, null, null);
        if (getFirst() == null) {
            setFirst(newNode);
            setLast(getFirst());
        } else {
            getFirst().setPrev(newNode);
            newNode.setNext(getFirst());
            setFirst(newNode);
        }
        setSize(getSize() + 1);

    }

    //Funcion para insertar elemento al final
    
    public void insertAtEnd(int user1, int user2, int time) {
        ConexNode newNode = new ConexNode(user1, user2, time, null, null);
        if (getFirst() == null) {
            setFirst(newNode);
            setLast(getFirst());
        } else {
            newNode.setPrev(getLast());
            getLast().setNext(newNode);
            setLast(newNode);
        }
        setSize(getSize() + 1);

    }
    
    //Funcion para insertar en una posicion dada
    
    public void insertAtPos(int user1, int user2, int time, int pos){
        ConexNode newNode = new ConexNode(user1, user2, time, null, null);
        if (pos == 1) {
            insertAtStart(user1, user2, time);
            return;
        }
        
        ConexNode aux = getFirst();
        for (int i = 2; i <= getSize(); i++) {
            if (i==pos) {
                ConexNode temp = aux.getNext();
                aux.setNext(newNode);
                newNode.setPrev(aux);
                newNode.setNext(temp);
                temp.setPrev(newNode);
            }
            aux = aux.getNext();
        }
        
        setSize(getSize() + 1);
    }
    
    //Funcion para eliminar en determinada posicion
    
    public void deleteAtPos(int pos){
        if (pos == 1) {
            if (getSize() == 1) {
                setFirst(null);
                setLast(null);
                setSize(0);
                return;
            }
            setFirst(getFirst().getNext());
            getFirst().setPrev(null);
            setSize(getSize() - 1);
            return;
        }
        
        if (pos == getSize()) {
            setLast(getLast().getPrev());
            getLast().setNext(null);
            setSize(getSize() - 1);
        }
        
        ConexNode aux = getFirst().getNext();
        for (int i = 2; i <= getSize(); i++) {
            if (i == pos) {
                ConexNode p = aux.getPrev();
                ConexNode n = aux.getNext();
                
                p.setNext(n);
                n.setPrev(p);
                setSize(getSize() - 1);
                return;
            }
            
            aux = aux.getNext();
        }
    }
    
    //Funcion para mostrar elementos
    
    public void display(){
        if (getSize() == 0) {
            JOptionPane.showMessageDialog(null, "La lista está vacía.");
            return;            
        }
        if (getFirst().getNext() == null) {
            JOptionPane.showMessageDialog(null, getFirst().getUser1() + " " + getFirst().getTime() + " " + getFirst().getUser2());
        }
        ConexNode aux = getFirst();
        JOptionPane.showMessageDialog(null, getFirst().getUser1() + " " + getFirst().getTime() + " " + getFirst().getUser2());
        aux = getFirst().getNext();
        while(aux.getNext() != null){
            JOptionPane.showMessageDialog(null, aux.getUser1() + " " + aux.getTime() + " " + aux.getUser2());  
            aux = aux.getNext();
        }
        JOptionPane.showMessageDialog(null, aux.getUser1() + " " + aux.getTime() + " " + aux.getUser2());       
    }

    /**
     * @return the first
     */
    public ConexNode getFirst() {
        return first;
    }

    /**
     * @param first the first to set
     */
    public void setFirst(ConexNode first) {
        this.first = first;
    }

    /**
     * @return the last
     */
    public ConexNode getLast() {
        return last;
    }

    /**
     * @param last the last to set
     */
    public void setLast(ConexNode last) {
        this.last = last;
    }

    /**
     * @param size the size to set
     */
    public void setSize(int size) {
        this.size = size;
    }

}
