/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

/**
 *
 * @author AROMERO
 */
public class ConexNode {
    
    private int user1;
    private int user2;
    private int time;
    private ConexNode next;
    private ConexNode prev;
    
    //Contructor del nodo
    
    public ConexNode(){

        this.next = null;
        this.prev = null;
    }
    
    public ConexNode(int user1, int user2, int time, ConexNode n, ConexNode p){
        this.user1 = user1;
        this.user2 = user2;
        this.time = time;
        this.next = n;
        this.prev = p;
    }

    /**
     * @return the user1
     */
    public int getUser1() {
        return user1;
    }

    /**
     * @param user1 the user1 to set
     */
    public void setUser1(int user1) {
        this.user1 = user1;
    }

    /**
     * @return the user2
     */
    public int getUser2() {
        return user2;
    }

    /**
     * @param user2 the user2 to set
     */
    public void setUser2(int user2) {
        this.user2 = user2;
    }

    /**
     * @return the next
     */
    public ConexNode getNext() {
        return next;
    }

    /**
     * @param next the next to set
     */
    public void setNext(ConexNode next) {
        this.next = next;
    }

    /**
     * @return the time
     */
    public int getTime() {
        return time;
    }

    /**
     * @param time the time to set
     */
    public void setTime(int time) {
        this.time = time;
    }

    /**
     * @return the prev
     */
    public ConexNode getPrev() {
        return prev;
    }

    /**
     * @param prev the prev to set
     */
    public void setPrev(ConexNode prev) {
        this.prev = prev;
    }

    
    
}
